﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WedPlanner.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;

namespace WeddingPlanner.Controllers
{
    public class HomeController : Controller
    {
        private static Context context;
        public HomeController(Context DbContext)
        {
            context = DbContext;
        }
        public IActionResult Index()
        {
            HttpContext.Session.Clear();
            return View("Index");
        }

        public IActionResult RegUser(User user)
        {
            Wrapper Wrapper = new Wrapper();
            Wrapper.User = user;
            if(ModelState.IsValid)
                {   
                User userInDB = context.Users.FirstOrDefault(u => u.Email == user.Email);
                if(userInDB != null)
                    {
                        ModelState.AddModelError("User.Email", "Email already in use!");
                        return View("Index", Wrapper);
                    } else {
                    PasswordHasher<User> Hasher = new PasswordHasher<User>();
                    user.Password = Hasher.HashPassword(user, user.Password);
                    context.Add(user);
                    context.SaveChanges();
                    }
                HttpContext.Session.SetInt32("UserId", user.UserId);
                return RedirectToAction("DashBoard");
                }
                
            return  View("Index");
        }

        public IActionResult LogUser(Login login)
        {   
            Wrapper Wrapper = new Wrapper();
            Wrapper.Login = login;
            if(ModelState.IsValid)
            {
                var userInDb = context.Users.FirstOrDefault(u => u.Email == login.Email);
                if(userInDb == null)
                {
                    ModelState.AddModelError("Login.Email", "Invalid Email/Password");
                    System.Console.WriteLine("Invalid Email");
                    
                    return View("Index", Wrapper);
                }
                var hasher = new PasswordHasher<Login>();
                var result = hasher.VerifyHashedPassword(login, userInDb.Password, login.Password);
                if(result == 0)
                {
                    System.Console.WriteLine("Result doesn't == 0");
                    ModelState.AddModelError("Login.Email", "User email and password do not match");
                    return View("Index", Wrapper);
                }
                HttpContext.Session.SetInt32("UserId", userInDb.UserId);
                System.Console.WriteLine("This should of succeeded");
                return RedirectToAction("DashBoard");
            }
            System.Console.WriteLine("This is all the way back at index");
            return RedirectToAction("Index");
        }

        [HttpGet("Dashboard")]
        public IActionResult DashBoard()
        {
            if(HttpContext.Session.GetInt32("UserId") == null)
            {
                System.Console.WriteLine("no one logged in");
                return RedirectToAction("Index");
            }
            var allWeddings = context.Weddings
            .Include(w => w.Guests).ToList();

            ViewBag.AllWeddings = allWeddings;
            
            int UserId = (int)HttpContext.Session.GetInt32("UserId");
            User CurrentUser = context.Users.FirstOrDefault(u => u.UserId == UserId);
            ViewBag.user = CurrentUser.UserId;

            return View("Dashboard", allWeddings);
        }

        [HttpGet("join/{WeddingId}")]
        public IActionResult Associate(int WeddingId)
        {
            int UserId = (int)HttpContext.Session.GetInt32("UserId");
            Association newJoin = new Association()
            {
                WeddingId = WeddingId,
                UserId = UserId
            };
            context.Guests.Add(newJoin);
            context.SaveChanges();
            return RedirectToAction("DashBoard");
        }

        [HttpGet("unjoin/{WeddingId}")]
        public IActionResult UnAssociate(int WeddingId)
        {   
            var UserId = (int)HttpContext.Session.GetInt32("UserId");
            var ToLeave = context.Guests.FirstOrDefault(w => w.WeddingId == WeddingId && w.UserId == UserId);
            context.Guests.Remove(ToLeave);
            context.SaveChanges();
            return RedirectToAction("DashBoard");
        }

        [HttpGet("Wedding")]
        public IActionResult Wedding()
        {
            if(HttpContext.Session.GetInt32("UserId") == null)
            {
                HttpContext.Session.Clear();
                System.Console.WriteLine("no one logged in");
                return View("Index");
            }
            return View("Wedding");
        }

        public IActionResult Create(Wedding wedding)
        {
             if(HttpContext.Session.GetInt32("UserId") == null)
            {
                HttpContext.Session.Clear();
                System.Console.WriteLine("no one logged in");
                return View("Index");
            }
            if(wedding.Date < wedding.CreatedAt)
            {
                ModelState.AddModelError(nameof(wedding.Date), "Must be a date in the future.");
                return View("Wedding", wedding);
            }
            if(ModelState.IsValid)
            {
                wedding.UserId = (int)HttpContext.Session.GetInt32("UserId");
                context.Add(wedding);
                context.SaveChanges();
                return RedirectToAction("DashBoard");
            } else {
                return View("Wedding");
            }
        }
        [HttpGet("/delete/{WeddingId}")]
        public IActionResult DeleteThisWedding(int weddingid)
        {
            Wedding WeddingToDelete = context.Weddings.SingleOrDefault(w => w.WeddingId == weddingid);
            context.Weddings.Remove(WeddingToDelete);
            context.SaveChanges();

            return RedirectToAction("DashBoard");

        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
