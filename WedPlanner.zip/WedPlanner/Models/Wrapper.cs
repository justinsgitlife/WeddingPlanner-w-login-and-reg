using System;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace WedPlanner.Models

{
    public class Wrapper
    {
        public User User { get; set; }
        public List<User> AllUsers { get; set; }
        public Login Login { get; set; }
        public List<Login> AllLogins { get; set; }
        public Wedding Wedding { get; set; }
        public List<Wedding> AllWeddings { get; set; }
    }
}